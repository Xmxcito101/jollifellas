import Anthropic from '@anthropic-ai/sdk'

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' })

  const { mood, location, activities } = req.body
  if (!mood || !location || !activities?.length)
    return res.status(400).json({ error: 'Missing required fields' })

  const prompt = `You are Jollifellas — Lagos' #1 AI weekend curator and entertainment guide. You are warm, witty, and deeply local.

User inputs:
- Mood: ${mood.label} (${mood.desc})
- Location: ${location}
- Activities: ${activities.join(', ')}

Create a detailed Lagos weekend itinerary. Output ONLY valid JSON — no markdown, no backticks, no extra text.

JSON format:
{
  "title": "Catchy Lagos-flavoured title",
  "tagline": "Short punchy one-liner",
  "items": [
    {
      "time": "10:00 AM",
      "category": "Category name",
      "icon": "single emoji",
      "name": "Real Lagos venue name with area",
      "desc": "2-3 vivid sentences about the experience",
      "tip": "One specific insider Lagos tip",
      "price_range": "₦ or ₦₦ or ₦₦₦"
    }
  ]
}

Rules:
- 5 to 7 stops across the full day
- Use REAL Lagos venues, streets, areas — be specific
- Match the mood and activity preferences tightly
- Write like a knowledgeable Lagos friend
- ₦ = budget friendly, ₦₦ = mid range, ₦₦₦ = upscale`

  try {
    const message = await client.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 1500,
      messages: [{ role: 'user', content: prompt }],
    })

    const raw = message.content[0].text.trim()
    const clean = raw.replace(/```json|```/g, '').trim()
    const itinerary = JSON.parse(clean)
    return res.status(200).json({ itinerary })
  } catch (err) {
    console.error('Itinerary error:', err)
    return res.status(500).json({ error: 'Failed to generate itinerary. Please try again.' })
  }
}
