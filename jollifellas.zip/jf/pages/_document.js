import { Html, Head, Main, NextScript } from 'next/document'
export default function Document() {
  return (
    <Html lang="en">
      <Head>
        <meta name="description" content="Jollifellas — AI-powered Lagos weekend planner." />
        <meta property="og:title" content="Jollifellas — Plan Your Lagos Weekend" />
        <meta property="og:description" content="Tell us your mood. We build your perfect Lagos day." />
        <meta name="theme-color" content="#08080E" />
      </Head>
      <body><Main /><NextScript /></body>
    </Html>
  )
}
