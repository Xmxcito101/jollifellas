import Head from 'next/head'
import { useState, useRef } from 'react'
import Header from '../components/Header'
import Hero from '../components/Hero'
import Planner from '../components/Planner'
import Loading from '../components/Loading'
import ItineraryResult from '../components/ItineraryResult'
import { FALLBACK } from '../components/data'

export default function Home() {
  const [view,      setView]      = useState('home')   // home | planner | loading | result
  const [loading,   setLoading]   = useState(false)
  const [itinerary, setItinerary] = useState(null)
  const [inputs,    setInputs]    = useState(null)
  const [error,     setError]     = useState(null)
  const topRef = useRef(null)

  const scrollTop = () => setTimeout(() => topRef.current?.scrollIntoView({ behavior: 'smooth' }), 80)

  const handleStart = () => { setView('planner'); scrollTop() }

  const handleSubmit = async ({ mood, location, activities }) => {
    setInputs({ mood, location, activities })
    setLoading(true)
    setView('loading')
    setError(null)
    scrollTop()

    try {
      const res  = await fetch('/api/itinerary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mood, location, activities }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed')
      setItinerary(data.itinerary)
    } catch (err) {
      const fallback = FALLBACK[mood.id] || FALLBACK['turn-up']
      setItinerary({ ...fallback, mood: mood.label, location })
      setError('Using a curated plan — AI temporarily unavailable.')
    } finally {
      setLoading(false)
      setView('result')
      scrollTop()
    }
  }

  const handleReset = () => {
    setView('home')
    setItinerary(null)
    setInputs(null)
    setError(null)
    scrollTop()
  }

  return (
    <>
      <Head>
        <title>Jollifellas — Plan Your Lagos Weekend</title>
      </Head>
      <div ref={topRef} />
      <Header />

      {view === 'home'    && <Hero onStart={handleStart} />}
      {view === 'planner' && <Planner onSubmit={handleSubmit} loading={loading} />}
      {view === 'loading' && <Loading mood={inputs?.mood} />}

      {view === 'result' && itinerary && (
        <>
          {error && (
            <div style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)', color: '#FCA5A5', padding: '10px 20px', fontSize: 13, textAlign: 'center' }}>
              ⚠️ {error}
            </div>
          )}
          <ItineraryResult itinerary={itinerary} inputs={inputs} onReset={handleReset} />
        </>
      )}
    </>
  )
}
