export const MOODS = [
  { id: 'turn-up',  emoji: '🔥', label: 'Turn Up',        desc: 'High energy, party mode' },
  { id: 'chill',    emoji: '😌', label: 'Chill Vibes',    desc: 'Relax and unwind' },
  { id: 'explore',  emoji: '🗺️', label: 'Explore Lagos',  desc: 'Tourist and culture deep dive' },
  { id: 'romantic', emoji: '💕', label: 'Romantic',       desc: 'Date night energy' },
  { id: 'foodie',   emoji: '🍲', label: 'Foodie Run',     desc: 'Chase the best bites in the city' },
  { id: 'culture',  emoji: '🎨', label: 'Arts & Culture', desc: 'Museums, galleries, live art' },
]

export const LOCATIONS = [
  'Victoria Island', 'Lekki Phase 1', 'Lekki Phase 2', 'Ikoyi',
  'Lagos Island', 'Surulere', 'Ikeja', 'Yaba', 'Ajah',
  'Oshodi', 'Festac Town', 'Apapa', 'Maryland', 'Agege', 'Gbagada',
]

export const ACTIVITY_TAGS = [
  { id: 'local-food',    label: 'Local Food',       emoji: '🍛' },
  { id: 'nightclub',     label: 'Nightclub',         emoji: '🎶' },
  { id: 'stripers',      label: 'Stripers Club',     emoji: '💃' },
  { id: 'beach',         label: 'Beach',             emoji: '🏖️' },
  { id: 'resort',        label: 'Resort',            emoji: '🌴' },
  { id: 'museum',        label: 'Museum',            emoji: '🏛️' },
  { id: 'art-gallery',   label: 'Art Gallery',       emoji: '🖼️' },
  { id: 'rooftop-bar',   label: 'Rooftop Bar',       emoji: '🥂' },
  { id: 'street-food',   label: 'Street Food',       emoji: '🌽' },
  { id: 'live-music',    label: 'Live Music',        emoji: '🎸' },
  { id: 'boat-cruise',   label: 'Boat Cruise',       emoji: '⛵' },
  { id: 'tourist-sites', label: 'Tourist Sites',     emoji: '📸' },
  { id: 'suya-spot',     label: 'Suya Spot',         emoji: '🍢' },
  { id: 'buka',          label: 'Buka / Mama-put',   emoji: '🥘' },
]

export const FALLBACK = {
  'turn-up': {
    title: 'Lagos Owambe Night Protocol',
    tagline: 'From sunset to sunrise — this is how Lagos turns up.',
    items: [
      { time: '4:00 PM', category: 'Pre-Game Food',   icon: '🍲', name: 'Buka Hut, Lekki Phase 1',       desc: 'Load up on smoky party jollof and peppered goat meat. Locals swear by this spot before any big night out.',                 tip: 'Order the catfish pepper soup as your starter.',                    price_range: '₦'   },
      { time: '7:30 PM', category: 'Cocktail Hour',   icon: '🥂', name: 'Circa Rooftop, Victoria Island', desc: 'Golden hour drinks above the Lagos skyline. Resident DJs spin Afrobeats while the Atlantic glitters below.',           tip: 'Arrive before 8PM to avoid the queue and get a good table.',        price_range: '₦₦₦' },
      { time: '10:00 PM',category: 'Main Club',        icon: '🎶', name: 'Quilox Club, Victoria Island',   desc: "Lagos' crown jewel of nightlife. Multi-floor experience, world-class DJs, foam parties every Saturday.",              tip: 'Book a VIP table in advance. Dress code strictly enforced.',         price_range: '₦₦₦' },
      { time: '2:00 AM', category: 'After Party',     icon: '🔥', name: 'Levels Lounge, Lekki',           desc: 'When Quilox winds down, Levels keeps the energy blazing until 5AM with raw unfiltered Lagos night-owl vibes.',         tip: "This is where the real Lagos insiders end up. No pretense.",         price_range: '₦₦'  },
      { time: '5:00 AM', category: 'Wind-Down Eats',  icon: '🍢', name: 'Suya Spot, Obalende',            desc: 'End the night the Lagos way — spiced suya, fried yam and cold drinks from vendors who never sleep.',                  tip: 'The mallam by the bridge is legendary. Ask for extra yaji.',         price_range: '₦'   },
    ],
  },
  'chill': {
    title: 'Lagos Easy Sunday Protocol',
    tagline: "Slow it down, breathe it in. Lagos has a softer side.",
    items: [
      { time: '9:00 AM', category: 'Slow Brunch',     icon: '☕', name: 'Café Neo, Lekki',                desc: 'Start slow with Nigerian coffee, akara sliders and a freshly made smoothie in a calm beautifully designed space.',       tip: 'Try their Chapman mocktail — incredibly refreshing.',                price_range: '₦₦'  },
      { time: '11:30 AM',category: 'Beach Chill',     icon: '🏖️', name: 'Elegushi Beach, Lekki',          desc: 'Private beach with sun beds, cold drinks and gentle Atlantic waves. More curated than Bar Beach with a calmer crowd.',   tip: 'Go before noon for the best spot. Entry fee applies on weekends.',   price_range: '₦'   },
      { time: '3:00 PM', category: 'Island Escape',   icon: '🌴', name: 'Ilashe Beach Resort',             desc: 'A hidden paradise accessible by boat from Maroko Jetty. Private island energy — hammocks, fresh seafood and total peace.', tip: 'Call ahead to arrange the 15-minute boat transfer.',                price_range: '₦₦₦' },
      { time: '6:00 PM', category: 'Sunset Drinks',   icon: '🌅', name: 'The Wharf, Lekki',               desc: 'Waterfront bar with gentle Afrobeats, cool lagoon breeze and stunning Lagos sunsets.',                                  tip: 'Order the pepper snail at sunset. Life-changing.',                   price_range: '₦₦'  },
      { time: '8:30 PM', category: 'Dinner',          icon: '🍽️', name: 'Nok by Alara, Victoria Island',  desc: 'Pan-African cuisine inside one of Lagos most beautiful restaurant spaces — art on the walls, culture on every plate.',   tip: 'The yam fries are genuinely a conversation starter.',                price_range: '₦₦₦' },
    ],
  },
  'explore': {
    title: 'Lagos Tourist Deep Dive',
    tagline: 'Old Lagos meets New Lagos — discover the city\'s true soul.',
    items: [
      { time: '8:00 AM', category: 'Heritage Start',  icon: '🏛️', name: 'National Museum, Onikan',         desc: 'Incredible collection of Benin bronzes, Yoruba artifacts and Nigerian history. Start your Lagos story here.',            tip: 'Hire a guide at the entrance — worth every naira.',                  price_range: '₦'   },
      { time: '10:30 AM',category: 'Historic Quarter',icon: '⛪', name: 'Brazilian Quarter, Lagos Island',  desc: 'Walk through Afro-Brazilian architecture built by returning slaves in the 1800s. Living history on every street.',        tip: 'The Jankara Market nearby is a sensory overload in the best way.',  price_range: '₦'   },
      { time: '12:30 PM',category: 'Local Lunch',     icon: '🍛', name: 'Buka Stop, Lagos Island',          desc: 'Authentic buka experience — eba, egusi, oha soup, assorted meat. Eat like a true Lagosian on a bench.',               tip: 'Point and choose — no menu, just ask what is available.',            price_range: '₦'   },
      { time: '2:30 PM', category: 'Art Gallery',     icon: '🖼️', name: 'Nike Art Gallery, Lekki',          desc: '5 floors and over 8,000 works of Nigerian art. Nike Davies-Okundaye\'s masterpiece space. Do not miss the top floor.',  tip: 'Free entry. Artists are often working on-site — chat with them.',   price_range: '₦'   },
      { time: '5:30 PM', category: 'Cultural Dinner', icon: '🌍', name: 'Terra Kulture, Victoria Island',   desc: 'Nigerian cultural centre with restaurant, theatre and bookshop. End your culture day with a proper Nigerian meal.',       tip: 'Check if there is a performance night — they do theatre regularly.', price_range: '₦₦'  },
    ],
  },
  'romantic': {
    title: 'Lagos Date Night Masterclass',
    tagline: 'Romance, Lagos-style. Let the city do the work.',
    items: [
      { time: '4:00 PM', category: 'Afternoon Escape',icon: '⛵', name: 'Lagos Lagoon Boat Cruise',         desc: 'Private boat ride at golden hour with champagne, cool breeze and the city skyline. Hard to beat anywhere in the world.',   tip: 'Book through Boat Lagos or Lekki Boat Club. 2-hour packages available.', price_range: '₦₦₦' },
      { time: '6:30 PM', category: 'Cocktails',       icon: '🍸', name: 'Crust & Cream Rooftop, Ikoyi',    desc: 'Elegant rooftop bar with intimate lighting, craft cocktails and skyline views. Perfect pre-dinner atmosphere.',           tip: 'Reserve a corner table for privacy.',                               price_range: '₦₦₦' },
      { time: '8:30 PM', category: 'Fine Dining',     icon: '🕯️', name: 'Georges Restaurant, Victoria Island', desc: 'French-Nigerian fusion in a converted colonial mansion. Candlelit garden terrace and impeccable service.',           tip: 'The duo of pepper soup and foie gras starter is a showstopper.',   price_range: '₦₦₦' },
      { time: '10:30 PM',category: 'Night Cap',       icon: '🥂', name: 'Hard Rock Cafe, Victoria Island',  desc: 'Live music, great cocktails and a relaxed vibe to close the night on a high note without the club chaos.',               tip: 'Friday nights have live bands from 10PM.',                          price_range: '₦₦'  },
    ],
  },
  'foodie': {
    title: 'Lagos Food Safari',
    tagline: "Nigeria's food capital has 24 hours of flavour waiting.",
    items: [
      { time: '8:00 AM', category: 'Breakfast',       icon: '🍳', name: 'Agege Bread Spot, Agege',          desc: 'Hot Agege bread straight from the oven with ewa agoyin and palm oil. This is the life-changing Lagos breakfast.',         tip: 'Get there early — it sells out by 9AM.',                            price_range: '₦'   },
      { time: '12:30 PM',category: 'Buka Lunch',      icon: '🍲', name: 'Mama Cass Restaurant, Surulere',   desc: 'The OG Lagos buka chain. Amala, gbegiri, ewedu, assorted — this is real Lagos lunch culture at its finest.',             tip: 'The Surulere branch is the most authentic location.',                price_range: '₦'   },
      { time: '3:00 PM', category: 'Snack Attack',    icon: '🥘', name: 'Mende Market, Maryland',           desc: 'Akara, moi moi, bole fish with pepper — afternoon snacking Lagos mainland style.',                                      tip: 'Follow the crowd and the smoke.',                                    price_range: '₦'   },
      { time: '5:30 PM', category: 'Seafood',         icon: '🦞', name: 'Shrimp Affairs, Lekki',            desc: 'Fresh seafood grilled and peppered to order. Prawns, crabs, lobster — all from Lagos waters that same day.',             tip: 'The grilled lobster with jollof rice is the move.',                 price_range: '₦₦'  },
      { time: '8:30 PM', category: 'Suya Night',      icon: '🍢', name: 'Suya Spot, Victoria Island',       desc: 'End the night at the most famous suya spot on the Island. Spiced beef wrapped in newspaper. Iconic Lagos.',              tip: 'Ask for extra yaji spice mix on the side.',                         price_range: '₦'   },
    ],
  },
  'culture': {
    title: 'Lagos Arts Weekend',
    tagline: "Lagos is Africa's cultural capital. Here's your proof.",
    items: [
      { time: '10:00 AM',category: 'Gallery',         icon: '🖼️', name: 'Nike Art Gallery, Lekki',          desc: 'The unmissable 5-floor temple of Nigerian art. Over 8,000 works, live artists, textile workshops you can join.',          tip: 'Spend at least 2 hours here. Take the stairs to the top first.',   price_range: '₦'   },
      { time: '12:30 PM',category: 'Lunch',           icon: '🍽️', name: 'Nok by Alara, Victoria Island',    desc: 'Where Lagos creatives have lunch. The space itself is a design statement — furniture, art and food all curated.',         tip: 'Try the moin moin terrine — you have never had it like this.',      price_range: '₦₦₦' },
      { time: '2:30 PM', category: 'Conservation',    icon: '🌿', name: 'Lekki Conservation Centre',         desc: 'Not just nature — rotating cultural exhibitions alongside the famous canopy walkway over the lagoon.',                    tip: 'The 401m canopy walkway is the longest in Africa.',                 price_range: '₦'   },
      { time: '6:30 PM', category: 'Theatre',         icon: '🎭', name: 'Terra Kulture, Victoria Island',    desc: 'Nigeria\'s premier arts centre. Rotating theatre performances, film screenings and contemporary art exhibitions.',         tip: 'Book ahead for weekend theatre performances — they sell out.',      price_range: '₦₦'  },
      { time: '8:30 PM', category: 'Jazz & Wine',     icon: '🎷', name: 'Jazz Hole, Ikoyi',                  desc: 'Lagos iconic jazz bar and vinyl record shop. Live music on weekends, fine wine and an intimate atmosphere.',               tip: 'The record shop attached has rare Afrobeat classics for sale.',     price_range: '₦₦'  },
    ],
  },
}
