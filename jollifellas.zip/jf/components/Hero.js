export default function Hero({ onStart }) {
  const chips = [
    ['🍲','Local Food'], ['🎶','Nightlife'], ['💃','Stripers'],
    ['🏖️','Beaches'], ['🏛️','Museums'], ['🖼️','Art & Culture'],
    ['⛵','Boat Cruise'], ['🍢','Suya Spots'],
  ]

  return (
    <section style={{ position: 'relative', padding: '80px 20px 60px', overflow: 'hidden', minHeight: '85vh', display: 'flex', alignItems: 'center' }}>
      {/* Ambient blobs */}
      <div style={{ position: 'absolute', width: 600, height: 600, borderRadius: '50%', filter: 'blur(110px)', background: 'radial-gradient(circle,rgba(232,98,42,0.14),transparent 70%)', top: -150, right: -200, animation: 'blob-drift 12s ease-in-out infinite', pointerEvents: 'none' }} />
      <div style={{ position: 'absolute', width: 400, height: 400, borderRadius: '50%', filter: 'blur(100px)', background: 'radial-gradient(circle,rgba(245,176,0,0.1),transparent 70%)', bottom: 0, left: -100, animation: 'blob-drift 16s ease-in-out infinite reverse', pointerEvents: 'none' }} />

      <div className="container" style={{ position: 'relative', zIndex: 1, width: '100%' }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, background: 'rgba(245,176,0,0.08)', border: '1px solid rgba(245,176,0,0.2)', padding: '7px 16px', borderRadius: 100, fontSize: 12, color: '#F5B000', letterSpacing: 0.5, fontWeight: 600, marginBottom: 28, animation: 'slide-up .6s cubic-bezier(.22,1,.36,1) forwards' }}>
          <span>⚡</span><span>Lagos Local Intelligence · Real-Time AI Curation</span>
        </div>

        <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(40px,9vw,72px)', fontWeight: 900, lineHeight: 1.05, letterSpacing: -2, marginBottom: 24, animation: 'slide-up .6s cubic-bezier(.22,1,.36,1) .1s both' }}>
          Your Lagos weekend,<br />
          <em style={{ fontStyle: 'italic', color: '#E8622A' }}>curated perfectly.</em>
        </h1>

        <p style={{ fontSize: 17, color: '#9A97A8', lineHeight: 1.65, maxWidth: 520, marginBottom: 40, animation: 'slide-up .6s cubic-bezier(.22,1,.36,1) .2s both' }}>
          Tell us your mood, your location, and what you're feeling —
          and we'll build you a Lagos experience you'll never forget.
          From jollof runs to nightclub protocols.
        </p>

        <button
          onClick={onStart}
          style={{ display: 'inline-flex', alignItems: 'center', gap: 10, background: 'linear-gradient(135deg,#E8622A,#C0391A)', color: '#fff', border: 'none', padding: '18px 40px', fontFamily: "'Syne', sans-serif", fontSize: 17, fontWeight: 700, borderRadius: 100, cursor: 'pointer', boxShadow: '0 8px 40px rgba(232,98,42,0.4)', transition: 'transform .2s,box-shadow .2s', marginBottom: 48, animation: 'slide-up .6s cubic-bezier(.22,1,.36,1) .3s both' }}
          onMouseEnter={e => { e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.boxShadow = '0 14px 50px rgba(232,98,42,0.5)' }}
          onMouseLeave={e => { e.currentTarget.style.transform = ''; e.currentTarget.style.boxShadow = '0 8px 40px rgba(232,98,42,0.4)' }}
        >
          <span>Plan My Weekend</span><span style={{ fontSize: 20 }}>→</span>
        </button>

        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, animation: 'slide-up .6s cubic-bezier(.22,1,.36,1) .4s both' }}>
          {chips.map(([emoji, label]) => (
            <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 5, background: '#12121F', border: '1px solid rgba(245,176,0,0.12)', padding: '7px 14px', borderRadius: 100, fontSize: 13, color: '#9A97A8', fontWeight: 500 }}>
              <span>{emoji}</span> {label}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
