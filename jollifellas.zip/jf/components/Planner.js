import { useState } from 'react'
import { MOODS, LOCATIONS, ACTIVITY_TAGS } from './data'

const MOOD_ACCENT = { 'turn-up': '#E8622A', chill: '#3B82F6', explore: '#10B981', romantic: '#EC4899', foodie: '#F59E0B', culture: '#8B5CF6' }

export default function Planner({ onSubmit, loading }) {
  const [step, setStep]           = useState(1)
  const [mood, setMood]           = useState(null)
  const [location, setLocation]   = useState('')
  const [activities, setActivities] = useState([])

  const toggle = id => setActivities(p => p.includes(id) ? p.filter(a => a !== id) : [...p, id])

  const submit = () => {
    const moodObj = MOODS.find(m => m.id === mood)
    const acts = activities.map(id => {
      const a = ACTIVITY_TAGS.find(t => t.id === id)
      return a ? `${a.emoji} ${a.label}` : id
    })
    onSubmit({ mood: moodObj, location, activities: acts })
  }

  const accent = mood ? (MOOD_ACCENT[mood] || '#E8622A') : '#E8622A'

  const btnBase = {
    border: 'none', fontFamily: "'Syne', sans-serif",
    fontWeight: 700, cursor: 'pointer', transition: 'all .2s',
  }

  return (
    <div style={{ padding: '32px 20px 80px', position: 'relative' }}>
      {/* Blobs */}
      <div style={{ position: 'fixed', width: 500, height: 500, borderRadius: '50%', filter: 'blur(120px)', background: 'radial-gradient(circle,rgba(232,98,42,0.1),transparent 70%)', top: -100, right: -100, pointerEvents: 'none', zIndex: 0 }} />
      <div style={{ position: 'fixed', width: 400, height: 400, borderRadius: '50%', filter: 'blur(100px)', background: 'radial-gradient(circle,rgba(245,176,0,0.08),transparent 70%)', bottom: 0, left: -80, pointerEvents: 'none', zIndex: 0 }} />

      <div className="container" style={{ position: 'relative', zIndex: 1 }}>

        {/* Progress */}
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 40 }}>
          {[1, 2, 3].map((n, i) => (
            <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 32, height: 32, borderRadius: '50%', border: `2px solid ${step >= n ? '#F5B000' : 'rgba(245,176,0,0.15)'}`,
                background: step > n ? 'rgba(34,197,94,0.12)' : step === n ? 'rgba(245,176,0,0.08)' : 'transparent',
                color: step > n ? '#22C55E' : step >= n ? '#F5B000' : '#9A97A8',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 13, fontWeight: 700, flexShrink: 0,
                borderColor: step > n ? '#22C55E' : step >= n ? '#F5B000' : 'rgba(245,176,0,0.15)',
              }}>
                {step > n ? '✓' : n}
              </div>
              <span style={{ fontSize: 12, color: step >= n ? '#F0EDE6' : '#9A97A8', fontWeight: 600, textTransform: 'uppercase', letterSpacing: 1, whiteSpace: 'nowrap' }}>
                {n === 1 ? 'Mood' : n === 2 ? 'Location' : 'Activities'}
              </span>
              {i < 2 && <div style={{ width: 28, height: 2, background: step > n ? '#22C55E' : 'rgba(245,176,0,0.12)', margin: '0 6px', flexShrink: 0 }} />}
            </div>
          ))}
        </div>

        {/* Step 1 — Mood */}
        {step === 1 && (
          <div className="fade-in">
            <div style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: 2.5, color: '#F5B000', fontWeight: 700, marginBottom: 8 }}>Step 1 of 3</div>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(26px,5vw,36px)', fontWeight: 900, marginBottom: 28, letterSpacing: -1 }}>What's your mood today?</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: 10, marginBottom: 32 }}>
              {MOODS.map(m => (
                <button key={m.id} onClick={() => setMood(m.id)}
                  style={{ ...btnBase, background: mood === m.id ? `rgba(${m.id === 'chill' ? '59,130,246' : m.id === 'explore' ? '16,185,129' : m.id === 'romantic' ? '236,72,153' : m.id === 'foodie' ? '245,159,11' : m.id === 'culture' ? '139,92,246' : '232,98,42'},0.08)` : '#12121F', border: `1.5px solid ${mood === m.id ? accent : 'rgba(245,176,0,0.1)'}`, padding: '16px', borderRadius: 18, display: 'flex', alignItems: 'center', gap: 12, textAlign: 'left' }}>
                  <span style={{ fontSize: 26, flexShrink: 0 }}>{m.emoji}</span>
                  <div>
                    <div style={{ color: '#F0EDE6', fontWeight: 700, fontSize: 14 }}>{m.label}</div>
                    <div style={{ color: '#9A97A8', fontSize: 12, marginTop: 2 }}>{m.desc}</div>
                  </div>
                </button>
              ))}
            </div>
            <button onClick={() => setStep(2)} disabled={!mood}
              style={{ ...btnBase, background: 'linear-gradient(135deg,#E8622A,#C0391A)', color: '#fff', padding: '16px 36px', borderRadius: 100, fontSize: 16, boxShadow: '0 6px 28px rgba(232,98,42,0.3)', opacity: mood ? 1 : 0.4, cursor: mood ? 'pointer' : 'not-allowed' }}>
              Continue →
            </button>
          </div>
        )}

        {/* Step 2 — Location */}
        {step === 2 && (
          <div className="fade-in">
            <button onClick={() => setStep(1)} style={{ ...btnBase, background: 'none', color: '#9A97A8', fontSize: 14, marginBottom: 20, padding: 0 }}>← Back</button>
            <div style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: 2.5, color: '#F5B000', fontWeight: 700, marginBottom: 8 }}>Step 2 of 3</div>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(26px,5vw,36px)', fontWeight: 900, marginBottom: 8, letterSpacing: -1 }}>Where are you in Lagos?</h2>
            <p style={{ fontSize: 15, color: '#9A97A8', marginBottom: 28 }}>We'll build your itinerary around your base area.</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 8, marginBottom: 32 }}>
              {LOCATIONS.map(loc => (
                <button key={loc} onClick={() => setLocation(loc)}
                  style={{ ...btnBase, background: location === loc ? 'rgba(232,98,42,0.1)' : '#12121F', border: `1.5px solid ${location === loc ? '#E8622A' : 'rgba(245,176,0,0.1)'}`, color: location === loc ? '#F5B000' : '#F0EDE6', padding: '12px 8px', borderRadius: 12, fontSize: 13, fontWeight: 500, textAlign: 'center' }}>
                  {loc}
                </button>
              ))}
            </div>
            <button onClick={() => setStep(3)} disabled={!location}
              style={{ ...btnBase, background: 'linear-gradient(135deg,#E8622A,#C0391A)', color: '#fff', padding: '16px 36px', borderRadius: 100, fontSize: 16, boxShadow: '0 6px 28px rgba(232,98,42,0.3)', opacity: location ? 1 : 0.4, cursor: location ? 'pointer' : 'not-allowed' }}>
              Continue →
            </button>
          </div>
        )}

        {/* Step 3 — Activities */}
        {step === 3 && (
          <div className="fade-in">
            <button onClick={() => setStep(2)} style={{ ...btnBase, background: 'none', color: '#9A97A8', fontSize: 14, marginBottom: 20, padding: 0 }}>← Back</button>
            <div style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: 2.5, color: '#F5B000', fontWeight: 700, marginBottom: 8 }}>Step 3 of 3</div>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(26px,5vw,36px)', fontWeight: 900, marginBottom: 8, letterSpacing: -1 }}>What are you into today?</h2>
            <p style={{ fontSize: 15, color: '#9A97A8', marginBottom: 28 }}>Pick everything that sounds good. Mix freely.</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 32 }}>
              {ACTIVITY_TAGS.map(tag => (
                <button key={tag.id} onClick={() => toggle(tag.id)}
                  style={{ ...btnBase, display: 'flex', alignItems: 'center', gap: 6, background: activities.includes(tag.id) ? 'rgba(232,98,42,0.1)' : '#12121F', border: `1.5px solid ${activities.includes(tag.id) ? '#E8622A' : 'rgba(245,176,0,0.1)'}`, color: activities.includes(tag.id) ? '#F5B000' : '#F0EDE6', padding: '9px 16px', borderRadius: 100, fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap' }}>
                  <span>{tag.emoji}</span><span>{tag.label}</span>
                  {activities.includes(tag.id) && <span style={{ fontSize: 11, color: '#22C55E', fontWeight: 700 }}>✓</span>}
                </button>
              ))}
            </div>

            <button
              onClick={submit}
              disabled={!activities.length || loading}
              style={{ ...btnBase, width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, background: loading ? 'rgba(232,98,42,0.5)' : 'linear-gradient(135deg,#E8622A,#C0391A)', color: '#fff', padding: '20px', borderRadius: 18, fontSize: 18, boxShadow: '0 8px 36px rgba(232,98,42,0.35)', opacity: activities.length && !loading ? 1 : 0.45, cursor: activities.length && !loading ? 'pointer' : 'not-allowed', minHeight: 64 }}>
              {loading
                ? <><span style={{ width: 20, height: 20, border: '2.5px solid rgba(255,255,255,0.3)', borderTopColor: '#fff', borderRadius: '50%', animation: 'spin .75s linear infinite', flexShrink: 0 }} /> Curating your Lagos plan...</>
                : '🎯 Build My Itinerary'}
            </button>
            {!activities.length && !loading && (
              <p style={{ textAlign: 'center', color: '#9A97A8', fontSize: 13, marginTop: 12 }}>Select at least one activity to continue</p>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
