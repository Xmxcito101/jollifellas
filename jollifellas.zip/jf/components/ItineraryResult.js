import { useState } from 'react'

function Card({ item, index }) {
  const [open, setOpen] = useState(false)
  return (
    <div style={{ background: '#12121F', border: '1px solid rgba(245,176,0,0.1)', borderRadius: 20, marginBottom: 12, overflow: 'hidden', animation: `slide-up .5s cubic-bezier(.22,1,.36,1) ${index * 0.08}s both`, transition: 'border-color .2s,transform .2s' }}
      onMouseEnter={e => { e.currentTarget.style.borderColor = 'rgba(245,176,0,0.25)'; e.currentTarget.style.transform = 'translateY(-1px)' }}
      onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(245,176,0,0.1)'; e.currentTarget.style.transform = '' }}>
      {/* Time bar */}
      <div style={{ background: 'rgba(245,176,0,0.04)', borderBottom: '1px solid rgba(245,176,0,0.1)', padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
        <span style={{ background: 'linear-gradient(135deg,#E8622A,#C0391A)', color: '#fff', padding: '3px 12px', borderRadius: 100, fontSize: 12, fontWeight: 700, whiteSpace: 'nowrap' }}>{item.time}</span>
        <span style={{ fontSize: 12, color: '#F5B000', textTransform: 'uppercase', letterSpacing: 1, fontWeight: 700, flex: 1 }}>{item.category}</span>
        {item.price_range && <span style={{ fontSize: 13, color: '#9A97A8', fontWeight: 600 }}>{item.price_range}</span>}
      </div>
      {/* Body */}
      <div style={{ display: 'flex', gap: 14, padding: '18px 16px' }}>
        <div style={{ fontSize: 30, flexShrink: 0, marginTop: 2 }}>{item.icon}</div>
        <div style={{ flex: 1 }}>
          <h3 style={{ fontWeight: 800, fontSize: 16, marginBottom: 6, color: '#F0EDE6', fontFamily: "'Syne', sans-serif" }}>{item.name}</h3>
          <p style={{ fontSize: 14, color: '#9A97A8', lineHeight: 1.6 }}>{item.desc}</p>
          {open && (
            <div style={{ marginTop: 12, padding: '12px 14px', background: 'rgba(245,176,0,0.05)', border: '1px solid rgba(245,176,0,0.18)', borderRadius: 12, fontSize: 13, color: '#F0EDE6', lineHeight: 1.55 }}>
              <span style={{ color: '#F5B000', fontWeight: 700 }}>💡 Jollifellas Tip: </span>{item.tip}
            </div>
          )}
        </div>
      </div>
      <button onClick={() => setOpen(o => !o)}
        style={{ width: '100%', background: 'none', border: 'none', borderTop: '1px solid rgba(245,176,0,0.08)', color: '#9A97A8', fontFamily: "'Syne', sans-serif", fontSize: 13, fontWeight: 500, padding: '10px 16px', cursor: 'pointer', textAlign: 'left', transition: 'color .2s' }}
        onMouseEnter={e => e.currentTarget.style.color = '#F5B000'}
        onMouseLeave={e => e.currentTarget.style.color = '#9A97A8'}>
        {open ? 'Hide insider tip ↑' : 'Show insider tip ↓'}
      </button>
    </div>
  )
}

export default function ItineraryResult({ itinerary, inputs, onReset }) {
  const [copied, setCopied] = useState(false)

  const copy = () => {
    const txt = itinerary.items.map(i => `${i.time} — ${i.name}\n${i.desc}\nTip: ${i.tip}`).join('\n\n')
    navigator.clipboard.writeText(`${itinerary.title}\n${itinerary.tagline}\n\n${txt}`)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div style={{ padding: '32px 20px 80px', position: 'relative' }}>
      <div style={{ position: 'fixed', width: 600, height: 600, borderRadius: '50%', filter: 'blur(120px)', background: 'radial-gradient(circle,rgba(232,98,42,0.08),transparent 70%)', top: -200, right: -200, pointerEvents: 'none', zIndex: 0 }} />
      <div className="container" style={{ position: 'relative', zIndex: 1 }}>
        {/* Header */}
        <div style={{ marginBottom: 8, animation: 'fade-in .4s ease forwards' }}>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 16 }}>
            <span style={{ background: 'rgba(232,98,42,0.1)', border: '1px solid rgba(232,98,42,0.3)', color: '#E8622A', padding: '5px 14px', borderRadius: 100, fontSize: 13, fontWeight: 600 }}>
              {inputs.mood.emoji} {inputs.mood.label}
            </span>
            <span style={{ background: 'rgba(245,176,0,0.08)', border: '1px solid rgba(245,176,0,0.25)', color: '#F5B000', padding: '5px 14px', borderRadius: 100, fontSize: 13, fontWeight: 600 }}>
              📍 {inputs.location}
            </span>
          </div>
          <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 'clamp(26px,5.5vw,44px)', fontWeight: 900, letterSpacing: -1.5, lineHeight: 1.1, marginBottom: 10 }}>{itinerary.title}</h2>
          <p style={{ fontSize: 16, color: '#9A97A8', lineHeight: 1.5, marginBottom: 24 }}>{itinerary.tagline}</p>
          <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 8 }}>
            <button onClick={copy}
              style={{ background: 'rgba(245,176,0,0.08)', border: '1px solid rgba(245,176,0,0.3)', color: '#F5B000', padding: '10px 22px', borderRadius: 100, fontFamily: "'Syne', sans-serif", fontSize: 14, fontWeight: 600, cursor: 'pointer', transition: 'background .2s' }}>
              {copied ? '✓ Copied!' : '📋 Copy Plan'}
            </button>
            <button onClick={onReset}
              style={{ background: '#12121F', border: '1px solid rgba(245,176,0,0.1)', color: '#9A97A8', padding: '10px 22px', borderRadius: 100, fontFamily: "'Syne', sans-serif", fontSize: 14, fontWeight: 600, cursor: 'pointer', transition: 'all .2s' }}>
              ← Plan Another
            </button>
          </div>
        </div>
        <div style={{ height: 1, background: 'rgba(245,176,0,0.1)', margin: '28px 0' }} />
        {/* Cards */}
        {itinerary.items?.map((item, i) => <Card key={i} item={item} index={i} />)}
        {/* Footer */}
        <div style={{ marginTop: 40, textAlign: 'center', padding: 32, background: '#12121F', border: '1px solid rgba(245,176,0,0.1)', borderRadius: 24 }}>
          <p style={{ color: '#9A97A8', fontSize: 15, marginBottom: 16 }}>Enjoyed this plan? Share Jollifellas with your squad.</p>
          <button
            onClick={() => navigator.share ? navigator.share({ title: 'Jollifellas', text: itinerary.title, url: window.location.href }) : navigator.clipboard.writeText(window.location.href)}
            style={{ background: 'linear-gradient(135deg,#E8622A,#C0391A)', color: '#fff', border: 'none', padding: '13px 30px', borderRadius: 100, fontFamily: "'Syne', sans-serif", fontSize: 15, fontWeight: 700, cursor: 'pointer', boxShadow: '0 6px 24px rgba(232,98,42,0.3)' }}>
            🔗 Share Jollifellas
          </button>
        </div>
      </div>
    </div>
  )
}
