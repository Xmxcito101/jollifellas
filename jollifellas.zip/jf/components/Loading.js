const MSGS = [
  'Scanning Lagos for the best vibes…',
  'Consulting our mainland informants…',
  "Checking the Island's hottest spots…",
  'Confirming the suya man is open…',
  'Routing around go-slow traffic…',
  'Curating your perfect Lagos day…',
]

export default function Loading({ mood }) {
  const msg = MSGS[Math.floor(Math.random() * MSGS.length)]
  return (
    <div style={{ minHeight: '70vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center', padding: '60px 20px', animation: 'fade-in .4s ease forwards' }}>
      <div style={{ position: 'relative', width: 80, height: 80, marginBottom: 32 }}>
        <div style={{ position: 'absolute', inset: 0, border: '3px solid rgba(245,176,0,0.12)', borderTopColor: '#E8622A', borderRadius: '50%', animation: 'spin .9s linear infinite' }} />
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 30 }}>
          {mood?.emoji || '🎉'}
        </div>
      </div>
      <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, fontWeight: 900, marginBottom: 10, letterSpacing: -0.5 }}>
        Building your itinerary
      </h2>
      <p style={{ fontSize: 15, color: '#9A97A8', marginBottom: 24 }}>{msg}</p>
      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        {[0, 0.18, 0.36].map((delay, i) => (
          <div key={i} style={{ width: 7, height: 7, background: '#E8622A', borderRadius: '50%', animation: `bounce-dot 1.2s ease-in-out ${delay}s infinite` }} />
        ))}
      </div>
    </div>
  )
}
