export default function Header() {
  return (
    <header style={{
      padding: '20px',
      position: 'sticky',
      top: 0,
      zIndex: 50,
      borderBottom: '1px solid rgba(245,176,0,0.1)',
      backdropFilter: 'blur(14px)',
      background: 'rgba(8,8,14,0.7)',
    }}>
      <div className="container" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 42, height: 42,
            background: 'linear-gradient(135deg,#E8622A,#C0391A)',
            borderRadius: 12,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 20, boxShadow: '0 4px 16px rgba(232,98,42,0.3)',
          }}>🎉</div>
          <div>
            <div style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: 22, fontWeight: 900, letterSpacing: -0.5,
              background: 'linear-gradient(135deg,#F5B000,#E8622A)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            }}>jollifellas</div>
            <div style={{ fontSize: 10, color: '#9A97A8', textTransform: 'uppercase', letterSpacing: 2 }}>
              Lagos Weekend AI
            </div>
          </div>
        </div>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 6,
          background: 'rgba(34,197,94,0.07)', border: '1px solid rgba(34,197,94,0.2)',
          padding: '5px 12px', borderRadius: 100,
        }}>
          <div style={{
            width: 6, height: 6, borderRadius: '50%', background: '#22C55E',
            animation: 'pulse-glow 2s ease-in-out infinite',
          }} />
          <span style={{ fontSize: 11, color: '#22C55E', fontWeight: 600 }}>AI Powered</span>
        </div>
      </div>
    </header>
  )
}
